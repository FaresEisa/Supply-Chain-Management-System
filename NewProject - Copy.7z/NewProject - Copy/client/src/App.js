import React from 'react';
import { useNavigate, Routes, Route } from 'react-router-dom';
import './App.css';
import MainPage from './MainPage';
import RegisterPage from './RegisterPage';

function App() {
    const navigate = useNavigate();

    const handleRegisterClick = () => {
        navigate('/register');
    };

    const handleLoginClick = () => {
        alert('Login button clicked!');
    };

    const handleCloseClick = () => {
        navigate('/');
    };

    return (
        <div className="App">
            <Routes>
                <Route path="/" element={<MainPage />} />
                <Route path="/register" element={<RegisterPage />} />
                <Route path="/buttons" element={
                    <div className="ButtonPage">
                        <button onClick={handleRegisterClick}>Register</button>
                        <button onClick={handleLoginClick}>Login</button>
                        <button onClick={handleCloseClick}>Close</button>
                    </div>
                } />
            </Routes>
        </div>
    );
}

export default App;
