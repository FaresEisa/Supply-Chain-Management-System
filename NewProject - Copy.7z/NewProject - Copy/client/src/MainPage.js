﻿import React from 'react';
import { useNavigate } from 'react-router-dom';  // Import useNavigate to use routing

function MainPage() {
    const navigate = useNavigate();  // Hook to navigate between pages

    const handleStartClick = () => {
        navigate('/buttons');  // Redirect to the buttons page when Start is clicked
    };

    return (
        <div className="MainPage">
            <h1>Main Page</h1>
            <p>Welcome to the main page!</p>
            <button onClick={handleStartClick}>Start</button>
        </div>
    );
}

export default MainPage;
