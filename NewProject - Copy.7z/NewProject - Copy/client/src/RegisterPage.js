﻿import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function RegisterPage() {
    const [selectedRole, setSelectedRole] = useState('');
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        confirmPassword: ''
    });

    const navigate = useNavigate();

    const handleRoleSelect = (role) => {
        setSelectedRole(role);
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (formData.password !== formData.confirmPassword) {
            alert('Passwords do not match!');
            return;
        }

        alert('Form submitted successfully!');
        console.log(formData);
    };

    const handleCancel = () => {
        navigate('/buttons');
    };

    return (
        <div className="RegisterPage">
            <h1>Register as:</h1>

            {!selectedRole ? (
                <>
                    <div className="role-selection">
                        <div className="role-selection-buttons">
                            <button onClick={() => handleRoleSelect('OWNER')}>OWNER</button>
                            <button onClick={() => handleRoleSelect('CLIENT')}>CLIENT</button>
                        </div>
                    </div>

                    {/* Cancel button properly placed */}
                    <div className="cancel-button-role-selection">
                        <button type="button" onClick={handleCancel}>CANCEL</button>
                    </div>
                </>
            ) : (
                <form onSubmit={handleSubmit}>
                    <h2>{selectedRole}</h2>

                    <div>
                        <label htmlFor="name">Name:</label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="email">Email:</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="password">Password:</label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            value={formData.password}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="confirmPassword">Confirm Password:</label>
                        <input
                            type="password"
                            id="confirmPassword"
                            name="confirmPassword"
                            value={formData.confirmPassword}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <button type="submit">Register</button>

                    {/* Cancel button for the form */}
                    <div className="cancel-button-form">
                        <button type="button" onClick={handleCancel}>Cancel</button>
                    </div>
                </form>
            )}
        </div>
    );
}

export default RegisterPage;