use supplyApiDb

CREATE TABLE Users (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Role NVARCHAR(50) NOT NULL,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL
);

-- Create an index on the Email column for faster lookups
CREATE INDEX IX_Users_Email ON Users (Email);

-- Create a unique index to ensure only one 'Owner' exists in the table
CREATE UNIQUE INDEX IX_Users_OneOwner
ON Users(Role)
WHERE Role = 'Owner';
