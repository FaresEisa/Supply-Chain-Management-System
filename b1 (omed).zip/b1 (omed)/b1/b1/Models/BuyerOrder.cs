﻿using System.ComponentModel.DataAnnotations;

namespace b1.Models
{
    public class BuyerOrder
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int BuyerId { get; set; }  // FK to User
        public User? Buyer { get; set; }

        [Required]
        public int ListingId { get; set; }  // FK to Listing
        public Listing? Listing { get; set; }

        [Required]
        public int SellerId { get; set; }  // FK to User (seller)
        public User? Seller { get; set; }

        [Required]
        public int Stock { get; set; }  // Consistent use of Stock instead of Quantity

        public decimal TotalPrice => (Listing?.Item?.Price ?? 0) * Stock;  // Calculate price based on Stock

        public DateTime CreatedDate { get; set; } = DateTime.Now;

        [Required]
        public string Status { get; set; } = "Active";  // or "Cancelled"
    }
}
