﻿namespace b1.Models
{
    public class Category
    {
        public int Id { get; set; }  // Primary Key
        public string? CategoryName { get; set; }  // Name of the Category (as per your SQL Insert)
        public string? CategoryType { get; set; }  // Type of Category (Goods/Services)
    }

}
