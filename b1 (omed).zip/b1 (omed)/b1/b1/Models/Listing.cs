﻿namespace b1.Models
{
    public class Listing
    {
        public int Id { get; set; }
        public int UserId { get; set; }  // Seller ID (references User)
        public User? User { get; set; }
        public int ItemId { get; set; }  // Item ID (references Item)
        public Item? Item { get; set; }
        public int Stock { get; set; }  // Stock available for sale (consistent with other models)

        // The total price is calculated as Stock * Price of the item
        public decimal TotalPrice => Item?.Price * Stock ?? 0;

        public DateTime CreatedDate { get; set; } = DateTime.Now;

        // Add a Status field for soft delete (can be Active or Cancelled)
        public string Status { get; set; } = "Active";  // Default to Active, can be changed to "Cancelled"
    }
}
