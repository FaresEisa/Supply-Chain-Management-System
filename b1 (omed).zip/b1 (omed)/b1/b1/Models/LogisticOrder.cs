﻿using System.ComponentModel.DataAnnotations;

namespace b1.Models
{
    public class LogisticOrder
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int SellerOrderId { get; set; }  // FK to SellerOrder
        public SellerOrder? SellerOrder { get; set; }

        [Required]
        public int AssignedTo { get; set; }  // FK to User (Logistic User)
        public User? AssignedLogisticUser { get; set; }

        [Required]
        public int Stock { get; set; }  // Consistent use of Stock instead of Quantity

        public decimal TotalPrice => SellerOrder?.Listing?.Item?.Price * Stock ?? 0;

        [Required]
        public string Status { get; set; } = "Active";  // "Active", "Shipped", "Delivered", etc.

        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}
