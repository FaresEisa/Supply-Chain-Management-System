﻿using System.ComponentModel.DataAnnotations.Schema;

namespace b1.Models
{
    public class Subcategory
    {
        public int Id { get; set; }  // Primary Key
        public string? SubcategoryName { get; set; }  // Name of the Subcategory

        // Foreign Key for the Category
        public int CategoryId { get; set; }

        // Navigation Property for Category (optional for easier access to related data)
        [ForeignKey("CategoryId")]
        public Category? Category { get; set; }
    }
}
