﻿using System.ComponentModel.DataAnnotations;

namespace b1.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }  // Primary Key, auto-generated ID

        [Required]
        public string? Role { get; set; }

        [Required]
        public string? Name { get; set; }

        [Required]
        [EmailAddress]
        public string? Email { get; set; }

        [Required]
        public string? Password { get; set; }  // Remember to hash this before saving
    }
}
