﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using b1.Data;
using b1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace b1.Pages
{
    public class ClientPageModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public ClientPageModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<Category> Categories { get; set; } = new List<Category>();
        public List<Subcategory> Subcategories { get; set; } = new List<Subcategory>();
        public List<Item> Items { get; set; } = new List<Item>();

        [BindProperty]
        public int ItemId { get; set; }

        [BindProperty]
        public int Quantity { get; set; }

        public void OnGet()
        {
            Categories = _context.Categories.ToList();
            Subcategories = _context.Subcategories.Include(s => s.Category).ToList();
            Items = _context.Items.Include(i => i.Subcategory).ToList();
        }

        public async Task<IActionResult> OnPostSellAsync()
        {
            Console.WriteLine($"[SELL] ItemId={ItemId}, Quantity={Quantity}");

            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                Console.WriteLine("❌ User not logged in.");
                return BadRequest("User not logged in.");
            }

            if (ItemId <= 0 || Quantity <= 0)
            {
                Console.WriteLine("❌ Invalid data: ItemId or Quantity is <= 0");
                return BadRequest("Invalid item or quantity.");
            }

            var item = await _context.Items.FindAsync(ItemId);
            if (item == null)
            {
                Console.WriteLine($"❌ Item not found in DB for ItemId={ItemId}");
                return BadRequest("Item not found.");
            }

            Console.WriteLine("✅ Passed all validation. Proceeding with sell...");

            var listing = await _context.Listings.FirstOrDefaultAsync(l => l.ItemId == ItemId && l.UserId == userId);
            if (listing != null)
            {
                listing.Stock += Quantity;
            }
            else
            {
                listing = new Listing
                {
                    UserId = userId.Value,
                    ItemId = ItemId,
                    Stock = Quantity,
                    Status = "Active",
                    CreatedDate = DateTime.Now
                };
                _context.Listings.Add(listing);
            }

            item.Stock += Quantity;
            await _context.SaveChangesAsync();
            return new JsonResult(new { message = "Sell successful" });
        }

        public async Task<IActionResult> OnPostBuyAsync()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                Console.WriteLine("❌ User not logged in on Buy.");
                return Unauthorized();
            }

            var item = await _context.Items.Include(i => i.Subcategory).FirstOrDefaultAsync(i => i.Id == ItemId);
            if (item == null || item.Stock < Quantity)
            {
                Console.WriteLine("❌ Insufficient stock or item not found.");
                return BadRequest("Insufficient stock.");
            }

            var listings = await _context.Listings
                .Where(l => l.ItemId == ItemId && l.Stock > 0)
                .OrderBy(l => l.CreatedDate)
                .ToListAsync();

            int remaining = Quantity;
            foreach (var listing in listings)
            {
                int take = Math.Min(remaining, listing.Stock);

                var buyerOrder = new BuyerOrder
                {
                    BuyerId = userId.Value,
                    SellerId = listing.UserId,
                    ListingId = listing.Id,
                    Stock = take,
                    CreatedDate = DateTime.Now,
                    Status = "Active"
                };
                _context.BuyerOrders.Add(buyerOrder);

                var sellerOrder = new SellerOrder
                {
                    BuyerOrder = buyerOrder,
                    ListingId = listing.Id,
                    SellerId = listing.UserId,
                    Stock = take,
                    CreatedDate = DateTime.Now,
                    Status = "Active"
                };
                _context.SellerOrders.Add(sellerOrder);

                var logisticOrder = new LogisticOrder
                {
                    SellerOrder = sellerOrder,
                    AssignedTo = 3,
                    Stock = take,
                    CreatedDate = DateTime.Now,
                    Status = "Active"
                };
                _context.LogisticOrders.Add(logisticOrder);

                listing.Stock -= take;
                item.Stock -= take;

                if (listing.Stock <= 0)
                {
                    _context.Listings.Remove(listing);
                }

                remaining -= take;
                if (remaining <= 0) break;
            }

            await _context.SaveChangesAsync();
            return RedirectToPage();
        }
    }
}