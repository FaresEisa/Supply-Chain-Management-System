﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using b1.Models;
using b1.Data;
using Microsoft.AspNetCore.Identity;

namespace b1.Pages
{
    public class LoginModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly PasswordHasher<User> _passwordHasher;

        public LoginModel(ApplicationDbContext context, PasswordHasher<User> passwordHasher)
        {
            _context = context;
            _passwordHasher = passwordHasher;
        }

        [BindProperty]
        public string? Email { get; set; }

        [BindProperty]
        public string? Password { get; set; }

        public void OnGet() { }

        public IActionResult OnPost()
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == Email);
            if (user == null)
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return Page();
            }

            if (string.IsNullOrEmpty(Password))
            {
                ModelState.AddModelError(string.Empty, "Password is required.");
                return Page();
            }

            if (string.IsNullOrEmpty(user.Password))
            {
                ModelState.AddModelError(string.Empty, "User's password is not available.");
                return Page();
            }

            var passwordVerificationResult = _passwordHasher.VerifyHashedPassword(user, user.Password, Password);
            if (passwordVerificationResult == PasswordVerificationResult.Failed)
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return Page();
            }

            // ✅ STORE user ID for Buy/Sell logic
            HttpContext.Session.SetInt32("UserId", user.Id);

            // Optional: store other info
            if (!string.IsNullOrEmpty(user.Email))
                HttpContext.Session.SetString("UserEmail", user.Email);

            if (!string.IsNullOrEmpty(user.Role))
                HttpContext.Session.SetString("UserRole", user.Role);

            if (!string.IsNullOrEmpty(user.Name))
                HttpContext.Session.SetString("UserName", user.Name);

            // ✅ Use case-insensitive role comparison
            var role = user.Role?.ToLower();

            return role switch
            {
                "client" => RedirectToPage("/ClientPage"),
                "owner" => RedirectToPage("/OwnerPage"),
                "logistic" => RedirectToPage("/LogisticPage"),
                _ => RedirectToPage("/Index"),
            };
        }
    }
}
