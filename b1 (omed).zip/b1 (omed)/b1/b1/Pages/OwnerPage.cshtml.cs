﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace b1.Pages
{
    public class OwnerPageModel : PageModel
    {
        public void OnGet()
        {
            // Add any logic you want to run when the page is loaded
        }
    }
}
