﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using b1.Models;
using b1.Data; // Reference to the database context
using Microsoft.AspNetCore.Identity;  // For PasswordHasher
using System.Linq;

namespace b1.Pages
{
    public class RegisterModel : PageModel
    {
        private readonly ILogger<RegisterModel> _logger;
        private readonly ApplicationDbContext _context;  // Inject DbContext
        private readonly PasswordHasher<User> _passwordHasher;  // Inject PasswordHasher

        public RegisterModel(ILogger<RegisterModel> logger, ApplicationDbContext context, PasswordHasher<User> passwordHasher)
        {
            _logger = logger;
            _context = context;
            _passwordHasher = passwordHasher;  // Initialize PasswordHasher
            NewUser = new User();  // Initialize NewUser in the constructor
        }

        [BindProperty]
        public User NewUser { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            // Check if the email already exists in the database
            if (_context.Users.Any(u => u.Email == NewUser.Email))
            {
                ModelState.AddModelError("NewUser.Email", "Email is already registered.");
                return BadRequest("Email is already registered.");
            }

            // Check if a user with the role 'owner' already exists
            if (NewUser.Role == "owner" && _context.Users.Any(u => u.Role == "owner"))
            {
                ModelState.AddModelError("NewUser.Role", "Only one owner can exist.");
                return BadRequest("Only one owner can exist.");
            }

            // Check if Password is provided and not empty
            if (string.IsNullOrEmpty(NewUser.Password))
            {
                ModelState.AddModelError("NewUser.Password", "Password cannot be empty.");
                return BadRequest("Password cannot be empty.");
            }

            // Hash the password before saving it
            NewUser.Password = _passwordHasher.HashPassword(NewUser, NewUser.Password);

            // Add the new user to the database
            _context.Users.Add(NewUser);
            _context.SaveChanges();

            // If everything is successful, return a success status or message
            return new OkResult();
        }
    }
}
