﻿using b1.Models;
using Microsoft.EntityFrameworkCore;

namespace b1.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Subcategory> Subcategories { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Listing> Listings { get; set; }
        public DbSet<BuyerOrder> BuyerOrders { get; set; }
        public DbSet<SellerOrder> SellerOrders { get; set; }
        public DbSet<LogisticOrder> LogisticOrders { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Ensure correct table names
            modelBuilder.Entity<Listing>().ToTable("Listings");

            // Handling cascade delete prevention for BuyerOrders
            modelBuilder.Entity<BuyerOrder>()
                .HasOne(b => b.Buyer)
                .WithMany()
                .HasForeignKey(b => b.BuyerId)
                .OnDelete(DeleteBehavior.Restrict); // Prevent cascading delete for BuyerId

            modelBuilder.Entity<BuyerOrder>()
                .HasOne(b => b.Seller)
                .WithMany()
                .HasForeignKey(b => b.SellerId)
                .OnDelete(DeleteBehavior.Restrict); // Prevent cascading delete for SellerId

            // Add cascade delete prevention for SellerOrders
            modelBuilder.Entity<SellerOrder>()
                .HasOne(s => s.Seller)
                .WithMany()
                .HasForeignKey(s => s.SellerId)
                .OnDelete(DeleteBehavior.Restrict); // Prevent cascading delete for SellerId

            modelBuilder.Entity<SellerOrder>()
                .HasOne(s => s.BuyerOrder)
                .WithMany()
                .HasForeignKey(s => s.BuyerOrderId)
                .OnDelete(DeleteBehavior.Restrict); // Prevent cascading delete for BuyerOrderId

            // Add cascade delete prevention for LogisticOrders
            modelBuilder.Entity<LogisticOrder>()
                .HasOne(l => l.SellerOrder)
                .WithMany()
                .HasForeignKey(l => l.SellerOrderId)
                .OnDelete(DeleteBehavior.Restrict); // Prevent cascading delete for SellerOrderId
        }

    }
}
