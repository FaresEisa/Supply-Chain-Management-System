﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace b1.Models
{
    public class Item
    {
        public int Id { get; set; }  // Primary Key

        [Required]
        public string? ItemName { get; set; }  // Name of the item

        public int SubcategoryId { get; set; }  // Foreign Key for Subcategory

        public int Stock { get; set; }  // Stock count (quantity)

        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }  // Price of the item

        // Navigation Property for Subcategory
        [ForeignKey("SubcategoryId")]
        public Subcategory? Subcategory { get; set; }
    }
}
