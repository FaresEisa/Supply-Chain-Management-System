﻿using b1.Models;
using System.ComponentModel.DataAnnotations;

public class LogisticOrder
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int SellerOrderId { get; set; }
    public SellerOrder? SellerOrder { get; set; }

    public int? LogisticId { get; set; }  // Nullable FK
    public User? Logistic { get; set; }

    [Required]
    public int Stock { get; set; }

    public decimal TotalPrice => SellerOrder?.Listing?.Item?.Price * Stock ?? 0;

    [Required]
    public string Status { get; set; } = "Active";

    public DateTime CreatedDate { get; set; } = DateTime.Now;
}
