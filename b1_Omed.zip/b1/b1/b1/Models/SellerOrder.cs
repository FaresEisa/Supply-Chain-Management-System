﻿using System.ComponentModel.DataAnnotations;

namespace b1.Models
{
    public class SellerOrder
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int BuyerOrderId { get; set; }  // FK to BuyerOrder
        public BuyerOrder? BuyerOrder { get; set; }

        [Required]
        public int SellerId { get; set; }  // FK to User
        public User? Seller { get; set; }

        [Required]
        public int ListingId { get; set; }  // FK to Listing
        public Listing? Listing { get; set; }

        [Required]
        public int Stock { get; set; }  // Consistent use of Stock instead of Quantity

        public decimal TotalPrice => Listing?.Item?.Price * Stock ?? 0;  // Calculate price based on Stock

        [Required]
        public string Status { get; set; } = "Active";  // "Active", "Cancelled", etc.

        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}
