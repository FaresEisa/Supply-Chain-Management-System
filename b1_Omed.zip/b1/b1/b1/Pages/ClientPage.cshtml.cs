﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using b1.Data;
using b1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

namespace b1.Pages
{
    public class ClientPageModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public ClientPageModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public string? UserName { get; set; }
        public string? UserRole { get; set; }

        public List<Category> Categories { get; set; } = new();
        public List<Subcategory> Subcategories { get; set; } = new();
        public List<Item> Items { get; set; } = new();
        public List<Listing> MyListings { get; set; } = new();
        public List<BuyerOrder> MyPurchases { get; set; } = new();
        public List<SellerOrder> MySales { get; set; } = new();

        [BindProperty]
        public int ItemId { get; set; }

        [BindProperty]
        public int Stock { get; set; }

        public IActionResult OnGet()
        {
            UserName = HttpContext.Session.GetString("UserName");
            UserRole = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(UserName) || UserRole != "client")
            {
                return RedirectToPage("/Login");
            }

            Categories = _context.Categories.ToList();
            Subcategories = _context.Subcategories.Include(s => s.Category).ToList();
            Items = _context.Items.Include(i => i.Subcategory).ToList();

            var email = HttpContext.Session.GetString("UserEmail");
            var user = _context.Users.FirstOrDefault(u => u.Email == email);

            if (user != null)
            {
                MyListings = _context.Listings
                    .Include(l => l.Item)
                    .Where(l => l.UserId == user.Id && l.Status == "Active")
                    .ToList();

                var userListings = MyListings;

                foreach (var item in Items)
                {
                    var userItemStock = userListings
                        .Where(l => l.ItemId == item.Id)
                        .Sum(l => l.Stock);

                    item.Stock -= userItemStock;
                }

                MyPurchases = _context.BuyerOrders
                    .Include(o => o.Listing).ThenInclude(l => l.Item)
                    .Include(o => o.Seller)
                    .Where(o => o.BuyerId == user.Id)
                    .OrderByDescending(o => o.CreatedDate)
                    .ToList();

                MySales = _context.SellerOrders
                    .Include(o => o.Listing).ThenInclude(l => l.Item)
                    .Include(o => o.BuyerOrder).ThenInclude(b => b.Buyer)
                    .Where(o => o.SellerId == user.Id)
                    .OrderByDescending(o => o.CreatedDate)
                    .ToList();
            }

            return Page();
        }

        public IActionResult OnPost()
        {
            if (Request.Form["action"] == "buy")
            {
                return OnPostBuy();
            }

            var email = HttpContext.Session.GetString("UserEmail");

            if (string.IsNullOrEmpty(email))
                return RedirectToPage("/Login");

            var user = _context.Users.FirstOrDefault(u => u.Email == email);
            var item = _context.Items.FirstOrDefault(i => i.Id == ItemId);

            if (user == null || item == null || Stock <= 0)
            {
                return RedirectToPage();
            }

            var existingListing = _context.Listings
                .FirstOrDefault(l => l.UserId == user.Id && l.ItemId == item.Id && l.Status == "Active");

            if (existingListing != null)
            {
                existingListing.Stock += Stock;
                existingListing.TotalPrice = existingListing.Stock * item.Price;
                _context.Listings.Update(existingListing);
            }
            else
            {
                var listing = new Listing
                {
                    UserId = user.Id,
                    ItemId = item.Id,
                    Stock = Stock,
                    TotalPrice = Stock * item.Price,
                    CreatedDate = DateTime.Now,
                    Status = "Active"
                };
                _context.Listings.Add(listing);
            }

            item.Stock += Stock;
            _context.Items.Update(item);

            _context.SaveChanges();

            return RedirectToPage();
        }

        public IActionResult OnPostBuy()
        {
            var email = HttpContext.Session.GetString("UserEmail");

            if (string.IsNullOrEmpty(email))
                return RedirectToPage("/Login");

            var user = _context.Users.FirstOrDefault(u => u.Email == email);
            var item = _context.Items.FirstOrDefault(i => i.Id == ItemId);

            if (user == null || item == null || Stock <= 0)
            {
                return RedirectToPage();
            }

            var listings = _context.Listings
                .Where(l => l.ItemId == item.Id && l.Status == "Active" && l.UserId != user.Id)
                .OrderBy(l => l.Stock)
                .ToList();

            int stockToBuy = Stock;
            var buyerOrders = new List<BuyerOrder>();
            var sellerOrders = new List<SellerOrder>();
            var logisticOrders = new List<LogisticOrder>();

            foreach (var listing in listings)
            {
                if (listing.Stock >= stockToBuy)
                {
                    var buyerOrder = new BuyerOrder
                    {
                        BuyerId = user.Id,
                        ListingId = listing.Id,
                        SellerId = listing.UserId,
                        Stock = stockToBuy,
                        Status = "Active",
                        CreatedDate = DateTime.Now
                    };
                    buyerOrders.Add(buyerOrder);

                    listing.Stock -= stockToBuy;
                    _context.Listings.Update(listing);
                    stockToBuy = 0;
                    break;
                }
                else
                {
                    var buyerOrder = new BuyerOrder
                    {
                        BuyerId = user.Id,
                        ListingId = listing.Id,
                        SellerId = listing.UserId,
                        Stock = listing.Stock,
                        Status = "Active",
                        CreatedDate = DateTime.Now
                    };
                    buyerOrders.Add(buyerOrder);

                    stockToBuy -= listing.Stock;
                    listing.Stock = 0;
                    _context.Listings.Update(listing);
                }

                if (stockToBuy == 0)
                    break;
            }

            if (stockToBuy > 0)
            {
                ModelState.AddModelError("Stock", "Not enough stock available to fulfill your order.");
                return Page();
            }

            foreach (var buyerOrder in buyerOrders)
            {
                var existing = _context.BuyerOrders.FirstOrDefault(b =>
                    b.BuyerId == buyerOrder.BuyerId &&
                    b.ListingId == buyerOrder.ListingId &&
                    b.Status == "Active");

                if (existing != null)
                {
                    existing.Stock += buyerOrder.Stock;
                    _context.BuyerOrders.Update(existing);
                    buyerOrder.Id = existing.Id;
                }
                else
                {
                    _context.BuyerOrders.Add(buyerOrder);
                }
            }
            _context.SaveChanges();

            foreach (var buyerOrder in buyerOrders)
            {
                var existing = _context.SellerOrders.FirstOrDefault(s =>
                    s.BuyerOrderId == buyerOrder.Id &&
                    s.SellerId == buyerOrder.SellerId &&
                    s.ListingId == buyerOrder.ListingId &&
                    s.Status == "Active");

                if (existing != null)
                {
                    existing.Stock += buyerOrder.Stock;
                    _context.SellerOrders.Update(existing);
                }
                else
                {
                    var sellerOrder = new SellerOrder
                    {
                        BuyerOrderId = buyerOrder.Id,
                        SellerId = buyerOrder.SellerId,
                        ListingId = buyerOrder.ListingId,
                        Stock = buyerOrder.Stock,
                        Status = "Active",
                        CreatedDate = DateTime.Now
                    };
                    _context.SellerOrders.Add(sellerOrder);
                    sellerOrders.Add(sellerOrder);
                }
            }
            _context.SaveChanges();

            foreach (var buyerOrder in buyerOrders)
            {
                var sellerOrder = _context.SellerOrders.FirstOrDefault(s =>
                    s.BuyerOrderId == buyerOrder.Id && s.Status == "Active");

                if (sellerOrder == null)
                    continue;

                var existingLogisticOrder = _context.LogisticOrders.FirstOrDefault(l =>
                    l.SellerOrderId == sellerOrder.Id && l.Status == "Active");

                if (existingLogisticOrder != null)
                {
                    existingLogisticOrder.Stock += buyerOrder.Stock;
                    _context.LogisticOrders.Update(existingLogisticOrder);
                }
                else
                {
                    var logisticOrder = new LogisticOrder
                    {
                        SellerOrderId = sellerOrder.Id,
                        LogisticId = null,
                        Stock = buyerOrder.Stock,
                        Status = "Active",
                        CreatedDate = DateTime.Now
                    };
                    _context.LogisticOrders.Add(logisticOrder);
                }
            }

            item.Stock -= Stock;
            _context.Items.Update(item);

            _context.SaveChanges();

            return RedirectToPage();
        }
    }
}
