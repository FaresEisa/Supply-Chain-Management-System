﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using b1.Models;
using b1.Data;
using Microsoft.AspNetCore.Identity;

namespace b1.Pages
{
    public class LoginModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly PasswordHasher<User> _passwordHasher;

        public LoginModel(ApplicationDbContext context, PasswordHasher<User> passwordHasher)
        {
            _context = context;
            _passwordHasher = passwordHasher;
        }

        [BindProperty]
        public string? Email { get; set; }  // Mark as nullable
        [BindProperty]
        public string? Password { get; set; }  // Mark as nullable

        public void OnGet()
        {
            // This will handle GET requests (display the login page)
        }

        public IActionResult OnPost()
        {
            // Find the user by email
            var user = _context.Users.FirstOrDefault(u => u.Email == Email);

            if (user == null)
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return Page();
            }

            // Ensure the password is not null or empty before verification
            if (string.IsNullOrEmpty(Password))
            {
                ModelState.AddModelError(string.Empty, "Password is required.");
                return Page();
            }

            // Ensure user.Password is not null before verifying password
            if (string.IsNullOrEmpty(user.Password))
            {
                ModelState.AddModelError(string.Empty, "User's password is not available.");
                return Page();
            }

            // Verify password using the PasswordHasher
            var passwordVerificationResult = _passwordHasher.VerifyHashedPassword(user, user.Password, Password);

            if (passwordVerificationResult == PasswordVerificationResult.Failed)
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return Page();
            }

            // Check for null values before setting session variables
            if (!string.IsNullOrEmpty(user.Email))
            {
                HttpContext.Session.SetString("UserEmail", user.Email);
            }

            if (!string.IsNullOrEmpty(user.Role))
            {
                HttpContext.Session.SetString("UserRole", user.Role);
            }

            if (!string.IsNullOrEmpty(user.Name))
            {
                HttpContext.Session.SetString("UserName", user.Name);
            }

            // Redirect to the role-based page after successful login
            if (user.Role == "owner")
            {
                return RedirectToPage("/OwnerPage");  // Redirect to OwnerPage
            }
            else if (user.Role == "client")
            {
                return RedirectToPage("/ClientPage");  // Redirect to ClientPage
            }
            else if (user.Role == "logistic")
            {
                return RedirectToPage("/LogisticPage");  // Redirect to LogisticPage
            }

            // Default redirect if role is unknown or not handled
            return RedirectToPage("/Home");
        }
    }
}
