﻿using b1.Data;
using b1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace b1.Pages
{
    public class LogisticPageModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public LogisticPageModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<LogisticOrder> AvailableOrders { get; set; }
        public List<LogisticOrder> AcceptedOrders { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var userEmail = HttpContext.Session.GetString("UserEmail");
            var userRole = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(userEmail) || userRole != "logistic")
                return RedirectToPage("/Login");

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == userEmail);
            if (user == null)
                return RedirectToPage("/Login");

            AvailableOrders = await _context.LogisticOrders
                .Include(lo => lo.SellerOrder)
                    .ThenInclude(so => so.Listing).ThenInclude(l => l.Item)
                .Include(lo => lo.SellerOrder)
                    .ThenInclude(so => so.Listing).ThenInclude(l => l.User)
                .Where(lo => lo.LogisticId == null)
                .ToListAsync();

            AcceptedOrders = await _context.LogisticOrders
                .Include(lo => lo.SellerOrder)
                    .ThenInclude(so => so.Listing).ThenInclude(l => l.Item)
                .Include(lo => lo.SellerOrder)
                    .ThenInclude(so => so.Listing).ThenInclude(l => l.User)
                .Where(lo => lo.LogisticId == user.Id)
                .ToListAsync();

            return Page();
        }

        public async Task<IActionResult> OnPostAcceptAsync(int orderId)
        {
            var userEmail = HttpContext.Session.GetString("UserEmail");
            var userRole = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(userEmail) || userRole != "logistic")
                return RedirectToPage("/Login");

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == userEmail);
            if (user == null)
                return RedirectToPage("/Login");

            var order = await _context.LogisticOrders.FirstOrDefaultAsync(o => o.Id == orderId && o.LogisticId == null);

            if (order != null)
            {
                order.LogisticId = user.Id;
                await _context.SaveChangesAsync();
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostUpdateStatusAsync(int orderId, string newStatus)
        {
            var userEmail = HttpContext.Session.GetString("UserEmail");
            var userRole = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(userEmail) || userRole != "logistic")
                return RedirectToPage("/Login");

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == userEmail);
            if (user == null)
                return RedirectToPage("/Login");

            var order = await _context.LogisticOrders
                .FirstOrDefaultAsync(o => o.Id == orderId && o.LogisticId == user.Id);

            if (order != null)
            {
                order.Status = newStatus;
                await _context.SaveChangesAsync();
            }

            return RedirectToPage();
        }
    }
}
