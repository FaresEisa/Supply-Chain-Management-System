﻿using b1.Data;
using b1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace b1.Pages
{
    public class OwnerPageModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public OwnerPageModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<User> Users { get; set; }
        public List<Listing> Listings { get; set; }
        public List<BuyerOrder> BuyerOrders { get; set; }
        public List<SellerOrder> SellerOrders { get; set; }
        public List<LogisticOrder> LogisticOrders { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var userName = HttpContext.Session.GetString("UserName");
            var userRole = HttpContext.Session.GetString("UserRole");

            // 🔒 Redirect to login if user is not logged in or not owner
            if (string.IsNullOrEmpty(userName) || userRole != "owner")
            {
                return RedirectToPage("/Login");
            }

            // ✅ Load all required data
            Users = await _context.Users.ToListAsync();

            Listings = await _context.Listings
                .Include(l => l.User)
                .Include(l => l.Item)
                .ToListAsync();

            BuyerOrders = await _context.BuyerOrders
                .Include(bo => bo.Buyer)
                .Include(bo => bo.Listing)
                    .ThenInclude(l => l.Item)
                .ToListAsync();

            SellerOrders = await _context.SellerOrders
                .Include(so => so.BuyerOrder)
                    .ThenInclude(bo => bo.Buyer)
                .Include(so => so.Listing)
                    .ThenInclude(l => l.Item)
                .Include(so => so.Seller)
                .ToListAsync();

            LogisticOrders = await _context.LogisticOrders
                .Include(lo => lo.SellerOrder)
                .Include(lo => lo.Logistic)
                .ToListAsync();

            return Page(); // ✅ Only return the page if authorized
        }
    }
}
