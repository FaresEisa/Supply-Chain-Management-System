﻿using b1.Data;
using b1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace b1.Pages
{
    public class OwnerPageModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public OwnerPageModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<User> Users { get; set; }
        public List<Listing> Listings { get; set; }
        public List<BuyerOrder> BuyerOrders { get; set; }
        public List<SellerOrder> SellerOrders { get; set; }
        public List<LogisticOrder> LogisticOrders { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? SearchTerm { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var userName = HttpContext.Session.GetString("UserName");
            var userRole = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(userName) || userRole != "owner")
            {
                return RedirectToPage("/Login");
            }

            // 🔍 Search user logic
            IQueryable<User> userQuery = _context.Users;

            if (!string.IsNullOrEmpty(SearchTerm))
            {
                userQuery = userQuery.Where(u =>
                    u.Name.Contains(SearchTerm) || u.Email.Contains(SearchTerm));
            }

            Users = await userQuery.ToListAsync();

            Listings = await _context.Listings
                .Include(l => l.User)
                .Include(l => l.Item)
                .ToListAsync();

            BuyerOrders = await _context.BuyerOrders
                .Include(bo => bo.Buyer)
                .Include(bo => bo.Seller)
                .Include(bo => bo.Listing)
                    .ThenInclude(l => l.Item)
                .ToListAsync();

            SellerOrders = await _context.SellerOrders
                .Include(so => so.BuyerOrder)
                    .ThenInclude(bo => bo.Buyer)
                .Include(so => so.BuyerOrder)
                    .ThenInclude(bo => bo.Seller)
                .Include(so => so.BuyerOrder)
                    .ThenInclude(bo => bo.Listing)
                        .ThenInclude(l => l.Item)
                .Include(so => so.Listing)
                    .ThenInclude(l => l.Item)
                .Include(so => so.Seller)
                .ToListAsync();

            LogisticOrders = await _context.LogisticOrders
                .Include(lo => lo.SellerOrder)
                    .ThenInclude(so => so.Listing).ThenInclude(l => l.Item)
                .Include(lo => lo.SellerOrder)
                    .ThenInclude(so => so.Listing).ThenInclude(l => l.User)
                .Include(lo => lo.SellerOrder)
                    .ThenInclude(so => so.BuyerOrder)
                        .ThenInclude(bo => bo.Buyer)
                .Include(lo => lo.Logistic)
                .ToListAsync();

            return Page();
        }
    }
}
