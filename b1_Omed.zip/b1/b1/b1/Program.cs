using Microsoft.EntityFrameworkCore;
using b1.Data;
using Microsoft.AspNetCore.Identity;  // Add this for PasswordHasher
using b1.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

// Add DbContext configuration to use the connection string from appsettings.json
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
);

// Add PasswordHasher for User to DI container
builder.Services.AddSingleton<PasswordHasher<User>>();  // Register PasswordHasher

// Add session services
builder.Services.AddDistributedMemoryCache();  // In-memory cache for session data
builder.Services.AddSession(options => {
    options.IdleTimeout = TimeSpan.FromMinutes(30);  // Session timeout
    options.Cookie.HttpOnly = true;  // Prevent access from JavaScript
    options.Cookie.IsEssential = true;
});

// ADD THIS:
builder.Services.AddAuthentication("MyCookieAuth")
    .AddCookie("MyCookieAuth", options =>
    {
        options.LoginPath = "/Login";
    });

builder.Services.AddAuthorization();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();

// Enable session middleware
app.UseSession();

app.UseRouting();
app.UseAuthentication();  // make sure this is before
app.UseAuthorization();   // this

// Define the Logout endpoint directly in Program.cs
app.MapGet("/Logout", (HttpContext context) =>
{
    // Clear the session to log out the user
    context.Session.Clear();

    // Redirect the user to the homepage after logging out
    return Results.Redirect("/Index");
});

app.MapStaticAssets();
app.MapRazorPages()
   .WithStaticAssets();

// Run the app
app.Run();
