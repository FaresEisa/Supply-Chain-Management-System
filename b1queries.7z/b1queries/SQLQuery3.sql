use b1db

---- Create the Subcategories table
--CREATE TABLE Subcategories (
--    Id INT IDENTITY(1,1) PRIMARY KEY,  -- Auto-incremented ID
--    SubcategoryName VARCHAR(255) NOT NULL,  -- Subcategory Name
--    CategoryId INT NOT NULL,  -- Foreign key to the Categories table
--    FOREIGN KEY (CategoryId) REFERENCES Categories(Id),  -- Link to Categories table
--    INDEX idx_category_id (CategoryId),  -- Index on CategoryId for efficient querying
--    INDEX idx_subcategory_name (SubcategoryName)  -- Index on SubcategoryName for fast search by name
--);


-- Insert subcategories for the Goods categories
INSERT INTO Subcategories (SubcategoryName, CategoryId)
VALUES
('Industrial Chemicals', (SELECT Id FROM Categories WHERE CategoryName = 'Chemicals for industry, science, and agriculture')),
('Agricultural Chemicals', (SELECT Id FROM Categories WHERE CategoryName = 'Chemicals for industry, science, and agriculture')),
('Laboratory Chemicals', (SELECT Id FROM Categories WHERE CategoryName = 'Chemicals for industry, science, and agriculture')),

('Paints for Industry', (SELECT Id FROM Categories WHERE CategoryName = 'Paints, varnishes, lacquers')),
('Household Paints', (SELECT Id FROM Categories WHERE CategoryName = 'Paints, varnishes, lacquers')),
('Decorative Paints', (SELECT Id FROM Categories WHERE CategoryName = 'Paints, varnishes, lacquers')),

('Face Creams', (SELECT Id FROM Categories WHERE CategoryName = 'Cosmetics and cleaning preparations')),
('Shampoos', (SELECT Id FROM Categories WHERE CategoryName = 'Cosmetics and cleaning preparations')),
('Soaps', (SELECT Id FROM Categories WHERE CategoryName = 'Cosmetics and cleaning preparations')),

('Lubricants for Machines', (SELECT Id FROM Categories WHERE CategoryName = 'Industrial oils and lubricants')),
('Automotive Oils', (SELECT Id FROM Categories WHERE CategoryName = 'Industrial oils and lubricants')),
('Greases', (SELECT Id FROM Categories WHERE CategoryName = 'Industrial oils and lubricants')),

('Human Pharmaceuticals', (SELECT Id FROM Categories WHERE CategoryName = 'Pharmaceuticals and veterinary preparations')),
('Veterinary Medicines', (SELECT Id FROM Categories WHERE CategoryName = 'Pharmaceuticals and veterinary preparations')),
('Over-the-counter Drugs', (SELECT Id FROM Categories WHERE CategoryName = 'Pharmaceuticals and veterinary preparations')),

('Ferrous Metals', (SELECT Id FROM Categories WHERE CategoryName = 'Metals and alloys')),
('Non-ferrous Metals', (SELECT Id FROM Categories WHERE CategoryName = 'Metals and alloys')),
('Alloy Steel', (SELECT Id FROM Categories WHERE CategoryName = 'Metals and alloys')),

('Industrial Machinery', (SELECT Id FROM Categories WHERE CategoryName = 'Machines and tools')),
('Hand-held Machinery', (SELECT Id FROM Categories WHERE CategoryName = 'Machines and tools')),
('Precision Machines', (SELECT Id FROM Categories WHERE CategoryName = 'Machines and tools')),

('Power Tools', (SELECT Id FROM Categories WHERE CategoryName = 'Hand tools')),
('Garden Tools', (SELECT Id FROM Categories WHERE CategoryName = 'Hand tools')),
('Measuring Tools', (SELECT Id FROM Categories WHERE CategoryName = 'Hand tools')),

('Optical Instruments', (SELECT Id FROM Categories WHERE CategoryName = 'Scientific and photographic equipment')),
('Surveying Instruments', (SELECT Id FROM Categories WHERE CategoryName = 'Scientific and photographic equipment')),
('Photography Equipment', (SELECT Id FROM Categories WHERE CategoryName = 'Scientific and photographic equipment')),

('Diagnostic Devices', (SELECT Id FROM Categories WHERE CategoryName = 'Medical devices')),
('Surgical Instruments', (SELECT Id FROM Categories WHERE CategoryName = 'Medical devices')),
('Prosthetic Devices', (SELECT Id FROM Categories WHERE CategoryName = 'Medical devices')),

('Lighting Equipment', (SELECT Id FROM Categories WHERE CategoryName = 'Environmental control apparatus')),
('Heating Systems', (SELECT Id FROM Categories WHERE CategoryName = 'Environmental control apparatus')),
('Air Conditioning Units', (SELECT Id FROM Categories WHERE CategoryName = 'Environmental control apparatus')),

('Motor Vehicles', (SELECT Id FROM Categories WHERE CategoryName = 'Vehicles and conveyances')),
('Aircraft', (SELECT Id FROM Categories WHERE CategoryName = 'Vehicles and conveyances')),
('Watercraft', (SELECT Id FROM Categories WHERE CategoryName = 'Vehicles and conveyances')),

('Firearms', (SELECT Id FROM Categories WHERE CategoryName = 'Firearms and ammunition')),
('Ammunition', (SELECT Id FROM Categories WHERE CategoryName = 'Firearms and ammunition')),
('Explosives', (SELECT Id FROM Categories WHERE CategoryName = 'Firearms and ammunition')),

('Gold', (SELECT Id FROM Categories WHERE CategoryName = 'Precious metals and alloys')),
('Silver', (SELECT Id FROM Categories WHERE CategoryName = 'Precious metals and alloys')),
('Platinum', (SELECT Id FROM Categories WHERE CategoryName = 'Precious metals and alloys')),

('String Instruments', (SELECT Id FROM Categories WHERE CategoryName = 'Musical instruments')),
('Wind Instruments', (SELECT Id FROM Categories WHERE CategoryName = 'Musical instruments')),
('Percussion Instruments', (SELECT Id FROM Categories WHERE CategoryName = 'Musical instruments')),

('Cardboard', (SELECT Id FROM Categories WHERE CategoryName = 'Paper, cardboard, and printed materials')),
('Printing Paper', (SELECT Id FROM Categories WHERE CategoryName = 'Paper, cardboard, and printed materials')),
('Printed Publications', (SELECT Id FROM Categories WHERE CategoryName = 'Paper, cardboard, and printed materials')),

('Rubber Sheets', (SELECT Id FROM Categories WHERE CategoryName = 'Rubber and plastics')),
('Plastic Packaging', (SELECT Id FROM Categories WHERE CategoryName = 'Rubber and plastics')),
('Plastic Pipes', (SELECT Id FROM Categories WHERE CategoryName = 'Rubber and plastics')),

('Leather Bags', (SELECT Id FROM Categories WHERE CategoryName = 'Leather goods')),
('Leather Belts', (SELECT Id FROM Categories WHERE CategoryName = 'Leather goods')),
('Leather Shoes', (SELECT Id FROM Categories WHERE CategoryName = 'Leather goods')),

('Cement', (SELECT Id FROM Categories WHERE CategoryName = 'Building materials')),
('Bricks', (SELECT Id FROM Categories WHERE CategoryName = 'Building materials')),
('Glass', (SELECT Id FROM Categories WHERE CategoryName = 'Building materials')),

('Sofas', (SELECT Id FROM Categories WHERE CategoryName = 'Furniture and mirrors')),
('Chairs', (SELECT Id FROM Categories WHERE CategoryName = 'Furniture and mirrors')),
('Tables', (SELECT Id FROM Categories WHERE CategoryName = 'Furniture and mirrors')),

('Cookware', (SELECT Id FROM Categories WHERE CategoryName = 'Household utensils')),
('Cutlery', (SELECT Id FROM Categories WHERE CategoryName = 'Household utensils')),
('Cleaning Tools', (SELECT Id FROM Categories WHERE CategoryName = 'Household utensils')),

('Ropes', (SELECT Id FROM Categories WHERE CategoryName = 'Ropes and nets')),
('Fishing Nets', (SELECT Id FROM Categories WHERE CategoryName = 'Ropes and nets')),
('Tents', (SELECT Id FROM Categories WHERE CategoryName = 'Ropes and nets')),

('Cotton Yarn', (SELECT Id FROM Categories WHERE CategoryName = 'Yarns and threads')),
('Wool Yarn', (SELECT Id FROM Categories WHERE CategoryName = 'Yarns and threads')),
('Synthetic Yarn', (SELECT Id FROM Categories WHERE CategoryName = 'Yarns and threads')),

('Bed Linen', (SELECT Id FROM Categories WHERE CategoryName = 'Textiles and textile goods')),
('Curtains', (SELECT Id FROM Categories WHERE CategoryName = 'Textiles and textile goods')),
('Towels', (SELECT Id FROM Categories WHERE CategoryName = 'Textiles and textile goods')),

('Jeans', (SELECT Id FROM Categories WHERE CategoryName = 'Clothing and footwear')),
('Shirts', (SELECT Id FROM Categories WHERE CategoryName = 'Clothing and footwear')),
('Sneakers', (SELECT Id FROM Categories WHERE CategoryName = 'Clothing and footwear')),

('Laces', (SELECT Id FROM Categories WHERE CategoryName = 'Lace, embroidery, ribbons')),
('Embroidery', (SELECT Id FROM Categories WHERE CategoryName = 'Lace, embroidery, ribbons')),
('Ribbons', (SELECT Id FROM Categories WHERE CategoryName = 'Lace, embroidery, ribbons')),

('Wool Carpets', (SELECT Id FROM Categories WHERE CategoryName = 'Carpets, rugs, and mats')),
('Cotton Mats', (SELECT Id FROM Categories WHERE CategoryName = 'Carpets, rugs, and mats')),
('Artificial Rugs', (SELECT Id FROM Categories WHERE CategoryName = 'Carpets, rugs, and mats')),

('Football', (SELECT Id FROM Categories WHERE CategoryName = 'Games and sports equipment')),
('Tennis Racquets', (SELECT Id FROM Categories WHERE CategoryName = 'Games and sports equipment')),
('Baseball Bats', (SELECT Id FROM Categories WHERE CategoryName = 'Games and sports equipment')),

('Fresh Meat', (SELECT Id FROM Categories WHERE CategoryName = 'Meat, fish, and oils')),
('Canned Fish', (SELECT Id FROM Categories WHERE CategoryName = 'Meat, fish, and oils')),
('Vegetable Oils', (SELECT Id FROM Categories WHERE CategoryName = 'Meat, fish, and oils')),

('Instant Coffee', (SELECT Id FROM Categories WHERE CategoryName = 'Coffee, tea, and foodstuffs')),
('Tea Bags', (SELECT Id FROM Categories WHERE CategoryName = 'Coffee, tea, and foodstuffs')),
('Sugar', (SELECT Id FROM Categories WHERE CategoryName = 'Coffee, tea, and foodstuffs')),

('Fruits', (SELECT Id FROM Categories WHERE CategoryName = 'Agricultural and forestry products')),
('Vegetables', (SELECT Id FROM Categories WHERE CategoryName = 'Agricultural and forestry products')),
('Herbs', (SELECT Id FROM Categories WHERE CategoryName = 'Agricultural and forestry products')),

('Soft Drinks', (SELECT Id FROM Categories WHERE CategoryName = 'Beverages (non-alcoholic)')),
('Mineral Water', (SELECT Id FROM Categories WHERE CategoryName = 'Beverages (non-alcoholic)')),
('Energy Drinks', (SELECT Id FROM Categories WHERE CategoryName = 'Beverages (non-alcoholic)')),

('Whisky', (SELECT Id FROM Categories WHERE CategoryName = 'Alcoholic beverages')),
('Wine', (SELECT Id FROM Categories WHERE CategoryName = 'Alcoholic beverages')),
('Vodka', (SELECT Id FROM Categories WHERE CategoryName = 'Alcoholic beverages')),

('Cigarettes', (SELECT Id FROM Categories WHERE CategoryName = 'Tobacco and smokers'' articles')),
('Smoking Pipes', (SELECT Id FROM Categories WHERE CategoryName = 'Tobacco and smokers'' articles')),
('Cigars', (SELECT Id FROM Categories WHERE CategoryName = 'Tobacco and smokers'' articles')),

-- Insert subcategories for the Services categories
('Advertising Services', (SELECT Id FROM Categories WHERE CategoryName = 'Advertising and business services')),
('Marketing Services', (SELECT Id FROM Categories WHERE CategoryName = 'Advertising and business services')),
('Business Consulting', (SELECT Id FROM Categories WHERE CategoryName = 'Advertising and business services')),

('Life Insurance', (SELECT Id FROM Categories WHERE CategoryName = 'Insurance and financial services')),
('Banking', (SELECT Id FROM Categories WHERE CategoryName = 'Insurance and financial services')),
('Real Estate Services', (SELECT Id FROM Categories WHERE CategoryName = 'Insurance and financial services')),

('Home Construction', (SELECT Id FROM Categories WHERE CategoryName = 'Construction and repair services')),
('Building Renovation', (SELECT Id FROM Categories WHERE CategoryName = 'Construction and repair services')),
('Plumbing', (SELECT Id FROM Categories WHERE CategoryName = 'Construction and repair services')),

('Internet Services', (SELECT Id FROM Categories WHERE CategoryName = 'Telecommunications')),
('Mobile Phone Services', (SELECT Id FROM Categories WHERE CategoryName = 'Telecommunications')),
('Satellite Communications', (SELECT Id FROM Categories WHERE CategoryName = 'Telecommunications')),

('Road Transport', (SELECT Id FROM Categories WHERE CategoryName = 'Transport and packaging services')),
('Air Freight', (SELECT Id FROM Categories WHERE CategoryName = 'Transport and packaging services')),
('Storage Services', (SELECT Id FROM Categories WHERE CategoryName = 'Transport and packaging services')),

('Metal Treatment', (SELECT Id FROM Categories WHERE CategoryName = 'Treatment of materials')),
('Plastic Treatment', (SELECT Id FROM Categories WHERE CategoryName = 'Treatment of materials')),
('Heat Treatment', (SELECT Id FROM Categories WHERE CategoryName = 'Treatment of materials')),

('Online Education', (SELECT Id FROM Categories WHERE CategoryName = 'Education and entertainment')),
('Training Courses', (SELECT Id FROM Categories WHERE CategoryName = 'Education and entertainment')),
('Entertainment Services', (SELECT Id FROM Categories WHERE CategoryName = 'Education and entertainment')),

('Tech Consulting', (SELECT Id FROM Categories WHERE CategoryName = 'Scientific and technological services')),
('Software Development', (SELECT Id FROM Categories WHERE CategoryName = 'Scientific and technological services')),
('Engineering Services', (SELECT Id FROM Categories WHERE CategoryName = 'Scientific and technological services')),

('Catering Services', (SELECT Id FROM Categories WHERE CategoryName = 'Food and accommodation services')),
('Hotel Accommodation', (SELECT Id FROM Categories WHERE CategoryName = 'Food and accommodation services')),
('Restaurant Services', (SELECT Id FROM Categories WHERE CategoryName = 'Food and accommodation services')),

('Medical Care', (SELECT Id FROM Categories WHERE CategoryName = 'Medical and beauty services')),
('Beauty Salons', (SELECT Id FROM Categories WHERE CategoryName = 'Medical and beauty services')),
('Spa Services', (SELECT Id FROM Categories WHERE CategoryName = 'Medical and beauty services')),

('Legal Advisory', (SELECT Id FROM Categories WHERE CategoryName = 'Legal and security services')),
('Security Services', (SELECT Id FROM Categories WHERE CategoryName = 'Legal and security services')),
('Legal Representation', (SELECT Id FROM Categories WHERE CategoryName = 'Legal and security services'));
